
package Juego;

import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class Enemy {
    
    private double x;
    private double y;
    
    private double velX = 0;
    
    private BufferedImage enemy;
    
    
    public Enemy(double x, double y,Game game){
        this.x = x;
        this.y = y;
        
        SpriteSheet ss = new SpriteSheet(game.getSpriteSheet("car"));
        
        enemy = ss.grabImage(24, 1, 107, 38);
        
    }
    
    public void tick(){
        x+=5;
        
        if(x > (Game.HEIGHT * Game.SCALE)+700){
            x=0;
        }
        
    }
    
    public void render(Graphics g){
        g.drawImage(enemy,(int) x,(int) y, null);
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getVelX() {
        return velX;
    }

    public void setVelX(double velX) {
        this.velX = velX;
    }
    
    
    
}
