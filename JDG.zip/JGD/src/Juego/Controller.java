
package Juego;

import java.awt.Graphics;
import java.util.LinkedList;


public class Controller {
    
    
    Game game;
    
    private LinkedList<Enemy> enemy = new LinkedList<Enemy>();
    
    Enemy TempEnemy;
    
    public Controller(Game game){
        this.game = game;
        
        addEnemy(new Enemy(-500,205,game));
        addEnemy(new Enemy(-200,280,game));
        addEnemy(new Enemy(-200,345,game));
        addEnemy(new Enemy(-100,410,game));
        addEnemy(new Enemy(0,485,game));
        
        // Los valores negativos de los carros cambia a una posicion mas alejada fuera de pantalla

        addEnemy(new Enemy(-300,605,game));
        addEnemy(new Enemy(-900,680,game));
        addEnemy(new Enemy(0,745,game));
        addEnemy(new Enemy(-300,810,game));
        addEnemy(new Enemy(-200,885,game));
    }
    
    
    public void tick(){
        
        for(int i=0;i<enemy.size();i++){
            TempEnemy = enemy.get(i);
            
            TempEnemy.tick();
        }
        
        
    }
    
    
    public void render(Graphics g){
        
        for(int i = 0; i< enemy.size();i++){
            TempEnemy = enemy.get(i);
            
            TempEnemy.render(g);
        }
        
    }
    
    
    public void addEnemy(Enemy block){
        enemy.add(block);
    }
    
    
    public void removeEnemy(Enemy block){
        enemy.remove(block);
    }
    
}
