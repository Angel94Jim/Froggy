
package Juego;

import java.awt.image.BufferedImage;


public class Textures {
    
    private BufferedImage player,enemy;
    
    private SpriteSheet ss = null;
    
    public Textures(Game game){
         ss = new SpriteSheet(game.getSpriteSheet("car"));
         
         getTextures();
    }
    
    
    private void getTextures(){
        player = ss.grabImage(1, 1, 64, 64);
        enemy = ss.grabImage(2,1,64,64);
    }
    
}
