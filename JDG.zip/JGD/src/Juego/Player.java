
package Juego;

import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class Player {
    
    private double x;
    private double y;
    
    private double velX = 0;
    private double velY = 0;
    
    private BufferedImage player;
    
    private Textures tex;
    
    public Player(double x,double y,Game game){
        this.x = x;
        this.y = y;
        
        SpriteSheet ss = new SpriteSheet(game.getSpriteSheet("player"));
        
        player = ss.grabImage(1, 1, 64, 64);
        
    }
    
    public void tick(){
        
        int limSuperiorX = 1380;
        int limInferiorX = 0;
        int limSuperiorY = 1020;
        int limInferiorY = 10;
        
        x+=velX;
        y+=velY;
        
        //Limitar los bordes de la pantalla para el movimiento
        
        if(x <= limInferiorX)
            x = limInferiorX;
        
        if(x >= limSuperiorX)
            x = limSuperiorX;
        
        if(y <= limInferiorY)
            y = limInferiorY;
        
        if(y >= limSuperiorY)
            y = limSuperiorY;
        
        
        
          if(y>1000){ // validar abajo
           y=950;}
                   
          if(y<30){//reset posicion una vez llega tope
           y=950;}
        
          if(x==1380){//valida derecha
           x=10;}
          
          if(x<1){ //valida izquierda
              x=1300;
          }

    }
    
    public void render(Graphics g){
        g.drawImage(player,(int) x,(int) y, null);
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getVelX() {
        return velX;
    }

    public void setVelX(double velX) {
        this.velX = velX;
    }

    public double getVelY() {
        return velY;
    }

    public void setVelY(double velY) {
        this.velY = velY;
    }
    
}
