
package Proyecto;

import java.awt.Image;
import javax.swing.ImageIcon;

public class Fondo {
    
    private String fondo; // ---> ayuda hacer el movimiento imagen = string campobits
    private int dx; //cordenada en x --> hacermovimiento
    private int dy; // cordenada en y --> hacer movimiento
    private int x; //posicionar objeto en x
    private int y; // posicionar objeto en y
    private Image imagen;
    
    public Fondo(){
        x=0; //posicion inicial
        y=-65; //posicion inicial //valores positivos son hacia abajo
        fondo="images/fondoo.png"; //crga imagen del sapo que se encuentra dentro del paquete
        
        ImageIcon img = new ImageIcon(this.getClass().getResource(fondo));//recurso a utilizar, y traer recurso el que esta en frog
        imagen=img.getImage();
      
    }
    
    //Metodo para conocer posicion actual Retornar valores de pos
    public int tenerX(){
        return x; //Retorna pos x
    }
    
    public int tenerY(){
        return y; // Retorn pos y
    }
    //contenido de x&&y
    public Image tenerImagen(){ 
        return imagen;
    }
}

  
