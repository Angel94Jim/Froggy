package Proyecto;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D; //graficar 2D
import java.awt.event.ActionEvent; //obtener eventos
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JPanel; //crear jpanes y ocurra toda la accion del programa
import javax.swing.Timer; 

public class Dibuja extends JPanel implements ActionListener {
    
    Player rana=new Player();
    Fondo fondo=new Fondo();
    Car car=new Car();
    Timer timer= new Timer(5,this);
    
    public Dibuja(){
        setBackground(Color.BLACK);// selecciona el color del fondo
        setFocusable(true);// se coloque dentro el objeto y se pueda mover se activa jpanel
        addKeyListener(new teclado());//instanciar clase telcado y capture lo que son teclas
        timer.start(); //empieza el timer
    }
    
    public void paint(Graphics grafica){ //recibe una grafica
        super.paint(grafica);
        Graphics2D g2= (Graphics2D)grafica; //va a provenir de graphics 2d
        //establecer imagen en pos
        g2.drawImage(rana.tenerImagen(),rana.tenerX(),rana.tenerY(),null);//Establece imagen en posicion(x,y);
        g2.drawImage(car.tenerImagen(),car.tenerX(),car.tenerY(),null);
        g2.drawImage(fondo.tenerImagen(),fondo.tenerX(),fondo.tenerY(),null);
         
        
    }
    
     public void actionPerformed(ActionEvent e){//cuando se detecte evento
        rana.mover();
        car.mover();
    
        repaint();// preestablecido con graphics
    }
    
      private class teclado extends KeyAdapter{
        
        public void keyPressed(KeyEvent e){
            rana.keyPressed(e);//cuando detecte tecla presionada mande a llamar rana.tecla presionada
            car.keyPressed(e);
        }
        
        public void keyReleased(KeyEvent e){
            rana.keyReleased(e);//tecla que se dejo de presionar
        
        }
        
    }
      
      
              
          
      }
  

